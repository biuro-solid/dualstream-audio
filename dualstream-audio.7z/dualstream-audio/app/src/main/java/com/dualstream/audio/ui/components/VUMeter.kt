package com.dualstream.audio.ui.components
import androidx.compose.foundation.Canvas; import androidx.compose.foundation.layout.size; import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier; import androidx.compose.ui.geometry.Offset; import androidx.compose.ui.graphics.Color; import androidx.compose.ui.unit.dp
@Composable fun VUMeter(level:Float, modifier:Modifier=Modifier){
  Canvas(modifier.size(120.dp)){ val h=size.height; val w=size.width; val y=h*(1 - level.coerceIn(0f,1f)); drawLine(Color.Green, Offset(0f,y), Offset(w,y), strokeWidth=8f) }
}