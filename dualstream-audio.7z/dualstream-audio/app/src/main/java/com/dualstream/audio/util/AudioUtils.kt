package com.dualstream.audio.util
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
fun enableIfAvailable(sessionId:Int){
  if(AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sessionId)?.enabled=true
  if(NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sessionId)?.enabled=true
  if(AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sessionId)?.enabled=true
}