package com.dualstream.audio.service
import android.app.Service; import android.content.Intent; import android.media.projection.MediaProjection; import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.dualstream.audio.audio.engine.AudioEngine
import com.dualstream.audio.util.createForegroundNotification
import com.dualstream.audio.util.NOTIF_ID
import kotlinx.coroutines.*
class ForegroundAudioService: Service(){
  private val scope=CoroutineScope(Dispatchers.Default); private lateinit var engine:AudioEngine; private var job:Job?=null
  override fun onBind(i:Intent?):IBinder?=null
  override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
    engine=AudioEngine(this); val stereo=i?.getBooleanExtra("stereo",true)?:true
    val proj=i?.getParcelableExtra<MediaProjection>("projection")
    ServiceCompat.startForeground(this, NOTIF_ID, createForegroundNotification(this, stereo), 0)
    if(proj!=null){ job?.cancel(); job=scope.launch{ engine.start(proj) } }
    return START_STICKY
  }
  override fun onDestroy(){ job?.cancel(); scope.launch{ engine.stop() }; super.onDestroy() }
}