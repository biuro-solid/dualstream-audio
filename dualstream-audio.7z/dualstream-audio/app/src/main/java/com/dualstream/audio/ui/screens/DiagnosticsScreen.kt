package com.dualstream.audio.ui.screens
import androidx.compose.foundation.layout.Column; import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text; import androidx.compose.runtime.Composable; import androidx.compose.ui.Modifier; import androidx.compose.ui.unit.dp
@Composable fun DiagnosticsScreen(){ Column(Modifier.padding(16.dp)){ Text("Diagnostyka — MVP"); Text("AudioPlaybackCapture, AEC/NS/AGC, bufory, latencja.") } }