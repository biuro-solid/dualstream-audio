package com.dualstream.audio
import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.dualstream.audio.ui.navigation.NavGraph
import com.dualstream.audio.ui.theme.DualStreamTheme
import com.dualstream.audio.viewmodel.MixerViewModel
import com.dualstream.audio.util.createProjectionIntent
class MainActivity: ComponentActivity() {
  private val vm: MixerViewModel by viewModels()
  private val projectionLauncher = registerForActivityResult(
    ActivityResultContracts.StartActivityForResult()
  ){
    if(it.resultCode==Activity.RESULT_OK && it.data!=null) vm.onProjectionGranted(it.data!!)
    else vm.onProjectionDenied()
  }
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent { DualStreamTheme { NavGraph(
      onRequestProjection = { projectionLauncher.launch(createProjectionIntent(this)) }
    ) } }
  }
}