package com.dualstream.audio.audio.mixer
import kotlin.math.sqrt; import kotlin.math.tanh
class AudioMixer {
  enum class Mode{ STEREO, MONO }
  var mode=Mode.STEREO; var talkGain=1f; var musicGain=1f; var talkPan=-1f; var musicPan=+1f
  private val talkDelay=FloatArray(1024); private var td=0
  fun render(outL:FloatArray,outR:FloatArray,talk:FloatArray,mL:FloatArray,mR:FloatArray,frames:Int){
    for(i in 0 until frames){
      val delayed=talkDelay[td]; talkDelay[td]=talk[i]; td=(td+1)%talkDelay.size
      val (tL,tR)=panMono(delayed*talkGain,talkPan)
      val (ml,mr)=panStereo(mL[i]*musicGain,mR[i]*musicGain,musicPan)
      var L=tL+ml; var R=tR+mr
      if(mode==Mode.MONO){ val m=(L+R)*0.5f; L=m; R=m }
      outL[i]=tanh(L); outR[i]=tanh(R)
    }
  }
  private fun panMono(x:Float, pan:Float):Pair<Float,Float>{ val p=(pan+1f)/2f; return x*sqrt(1-p) to x*sqrt(p) }
  private fun panStereo(l:Float,r:Float, pan:Float):Pair<Float,Float>{ val (pl,pr)=panMono(1f,pan); return l*pl to r*pr }
}