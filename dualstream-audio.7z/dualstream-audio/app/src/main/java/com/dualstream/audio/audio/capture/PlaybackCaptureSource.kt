package com.dualstream.audio.audio.capture
import android.media.*; import android.media.projection.MediaProjection
import kotlinx.coroutines.sync.Mutex; import kotlinx.coroutines.sync.withLock
class PlaybackCaptureSource {
  private var rec: AudioRecord?=null
  private val mtx=Mutex()
  private val ringSize=48000*2
  private val ring=FloatArray(ringSize); private var w=0
  suspend fun start(mp: MediaProjection)=mtx.withLock{
    stop()
    val cfg=AudioPlaybackCaptureConfiguration.Builder(mp)
      .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
      .addMatchingUsage(AudioAttributes.USAGE_GAME).build()
    val fmt=AudioFormat.Builder().setSampleRate(48000).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
    val min=AudioRecord.getMinBufferSize(48000,AudioFormat.CHANNEL_IN_STEREO,AudioFormat.ENCODING_PCM_FLOAT)
    rec=AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes((min*2).coerceAtLeast(48000)*4).setAudioPlaybackCaptureConfig(cfg).build()
    rec?.startRecording()
    Thread{
      val tmp=FloatArray(2048)
      while(rec?.recordingState==AudioRecord.RECORDSTATE_RECORDING){
        val n=rec?.read(tmp,0,tmp.size,AudioRecord.READ_BLOCKING)?:break
        var i=0; while(i<n){ ring[w]=tmp[i]; w=(w+1)%ringSize; i++ }
      }
    }.start()
  }
  fun readStereo(L:FloatArray,R:FloatArray,frames:Int){
    var idx=(w-frames*2+ringSize)%ringSize; var i=0
    while(i<frames){ L[i]=ring[idx]; R[i]=ring[(idx+1)%ringSize]; idx=(idx+2)%ringSize; i++ }
  }
  suspend fun stop()=mtx.withLock{ rec?.stop(); rec?.release(); rec=null }
}