package com.dualstream.audio.viewmodel
import android.app.Application; import android.content.Intent; import android.media.projection.MediaProjection
import androidx.lifecycle.AndroidViewModel
import com.dualstream.audio.service.ForegroundAudioService
import kotlinx.coroutines.flow.MutableStateFlow; import kotlinx.coroutines.flow.StateFlow
class MixerViewModel(app:Application):AndroidViewModel(app){
  private val _isStereo=MutableStateFlow(true); val isStereo:StateFlow<Boolean>=_isStereo
  var balancePreset="50/50"
  private var projection:Intent?=null
  fun onProjectionGranted(data:Intent){ projection=data }
  fun onProjectionDenied(){ projection=null }
  fun toggleStereo(){ _isStereo.value=!_isStereo.value }
  fun setBalancePreset(p:String){ balancePreset=p /* TODO: send to engine */ }
  fun startService(){
    val ctx=getApplication<Application>()
    val it=Intent(ctx, ForegroundAudioService::class.java)
    it.putExtra("stereo", _isStereo.value)
    it.putExtra("projection", projection?.getParcelableExtra<MediaProjection>("android.media.projection.extra.EXTRA_MEDIA_PROJECTION"))
    ctx.startForegroundService(it)
  }
  fun stopService(){ val ctx=getApplication<Application>(); ctx.stopService(Intent(ctx, ForegroundAudioService::class.java)) }
  fun testLR(){ /* TODO via binder */ }
}