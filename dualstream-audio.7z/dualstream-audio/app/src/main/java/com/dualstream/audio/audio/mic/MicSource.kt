package com.dualstream.audio.audio.mic
import android.media.*; import com.dualstream.audio.util.enableIfAvailable
class MicSource {
  private var rec: AudioRecord?=null
  var sessionId=0; private set
  fun start():Boolean{
    val fmt=AudioFormat.Builder().setSampleRate(48000).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
    val min=AudioRecord.getMinBufferSize(48000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_FLOAT)
    rec=AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(min*2).build()
    rec?.startRecording(); sessionId=rec?.audioSessionId?:0
    if(sessionId!=0) enableIfAvailable(sessionId); return rec?.recordingState==AudioRecord.RECORDSTATE_RECORDING
  }
  fun readMono(out:FloatArray,frames:Int){ rec?.read(out,0,frames,AudioRecord.READ_BLOCKING) }
  fun stop(){ rec?.stop(); rec?.release(); rec=null }
}