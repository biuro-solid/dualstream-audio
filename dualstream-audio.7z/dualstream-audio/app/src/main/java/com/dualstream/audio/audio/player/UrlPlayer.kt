package com.dualstream.audio.audio.player
import android.content.Context
import androidx.media3.common.MediaItem; import androidx.media3.common.MimeTypes; import androidx.media3.exoplayer.ExoPlayer
class UrlPlayer(private val ctx:Context){
  private var p:ExoPlayer?=null
  fun prepare(url:String, autoPlay:Boolean=true){ if(p==null) p=ExoPlayer.Builder(ctx).build(); p!!.setMediaItem(MediaItem.Builder().setUri(url).setMimeType(MimeTypes.AUDIO_UNKNOWN).build()); p!!.prepare(); p!!.playWhenReady=autoPlay }
  fun setVolume(v:Float){ p?.volume=v.coerceIn(0f,1f) }
  fun play(){ p?.play() }; fun pause(){ p?.pause() }; fun stop(){ p?.stop() }; fun release(){ p?.release(); p=null }
}