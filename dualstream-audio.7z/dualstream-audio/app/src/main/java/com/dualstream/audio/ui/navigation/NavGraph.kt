package com.dualstream.audio.ui.navigation
import androidx.compose.runtime.Composable
import androidx.navigation.compose.*
import com.dualstream.audio.ui.screens.*
sealed class Dest(val route:String){ object Onboarding:Dest("onboarding"); object Mixer:Dest("mixer"); object Web:Dest("web"); object Diag:Dest("diag"); object About:Dest("about") }
@Composable
fun NavGraph(onRequestProjection:()->Unit){
  val nav=rememberNavController()
  NavHost(nav, startDestination=Dest.Onboarding.route){
    composable(Dest.Onboarding.route){ OnboardingScreen(onRequestProjection){ nav.navigate(Dest.Mixer.route) } }
    composable(Dest.Mixer.route){ MixerScreen({ nav.navigate(Dest.Web.route) }, { nav.navigate(Dest.Diag.route) }, { nav.navigate(Dest.About.route) }) }
    composable(Dest.Web.route){ WebViewPlayerScreen() }
    composable(Dest.Diag.route){ DiagnosticsScreen() }
    composable(Dest.About.route){ AboutScreen() }
  }
}