package com.dualstream.audio.util
import android.app.*; import android.content.*; import androidx.core.app.NotificationCompat
import com.dualstream.audio.MainActivity; import com.dualstream.audio.R
const val CHANNEL_ID="dualstream_channel"; const val NOTIF_ID=101
fun createForegroundNotification(ctx:Context, isStereo:Boolean): Notification{
  val nm=ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  if(android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.O){
    nm.createNotificationChannel(NotificationChannel(CHANNEL_ID,"DualStream",NotificationManager.IMPORTANCE_LOW))
  }
  val pi=PendingIntent.getActivity(ctx,0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
  return NotificationCompat.Builder(ctx, CHANNEL_ID)
    .setSmallIcon(R.drawable.ic_notification)
    .setContentTitle(ctx.getString(R.string.app_name))
    .setContentText("Pomysłodawca: Tomasz Kolasa • "+(if(isStereo) "STEREO" else "MONO"))
    .setContentIntent(pi).setOngoing(true).build()
}