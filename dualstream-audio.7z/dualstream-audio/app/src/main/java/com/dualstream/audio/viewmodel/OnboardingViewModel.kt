package com.dualstream.audio.viewmodel
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow; import kotlinx.coroutines.flow.asStateFlow
class OnboardingViewModel: ViewModel(){ private val _micGranted=MutableStateFlow(false); val micGranted=_micGranted.asStateFlow(); fun setMicGranted(v:Boolean){ _micGranted.value=v } }