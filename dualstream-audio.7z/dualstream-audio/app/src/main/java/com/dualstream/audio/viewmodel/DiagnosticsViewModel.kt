package com.dualstream.audio.viewmodel
import androidx.lifecycle.ViewModel
class DiagnosticsViewModel: ViewModel()