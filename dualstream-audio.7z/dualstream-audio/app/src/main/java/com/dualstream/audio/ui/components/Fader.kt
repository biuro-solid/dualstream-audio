package com.dualstream.audio.ui.components
import androidx.compose.foundation.layout.*; import androidx.compose.material3.*; import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment; import androidx.compose.ui.Modifier; import androidx.compose.ui.unit.dp
@Composable fun Fader(title:String,value:Float,onChange:(Float)->Unit,modifier:Modifier=Modifier){
  Column(modifier, horizontalAlignment=Alignment.CenterHorizontally){ Text(title); Slider(value,onValueChange=onChange, valueRange=0f..1f, modifier=Modifier.width(220.dp)) }
}