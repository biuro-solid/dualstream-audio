package com.dualstream.audio.ui.screens
import android.annotation.SuppressLint; import android.content.Context; import android.webkit.*
import androidx.compose.foundation.layout.*; import androidx.compose.material3.*; import androidx.compose.runtime.*; import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext; import androidx.compose.ui.unit.dp; import androidx.compose.ui.viewinterop.AndroidView
import com.dualstream.audio.audio.player.UrlPlayer
@SuppressLint("SetJavaScriptEnabled")
@Composable fun WebViewPlayerScreen(){
  val ctx=LocalContext.current
  var url by remember{ mutableStateOf("https://raportostanieswiata.pl/") }
  var useUrl by remember{ mutableStateOf(true) }
  var streamUrl by remember{ mutableStateOf("https://stream.radio357.pl") }
  var vol by remember{ mutableStateOf(1f) }
  val urlPlayer=remember{ UrlPlayer(ctx) }
  LaunchedEffect(useUrl,streamUrl){ if(useUrl) urlPlayer.prepare(streamUrl,true) else urlPlayer.pause() }
  LaunchedEffect(vol){ urlPlayer.setVolume(vol) }
  Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement=Arrangement.spacedBy(8.dp)){
    Text("Źródło muzyki")
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
      FilterChip(useUrl, onClick={useUrl=true}, label={ Text("Odtwarzacz URL") })
      FilterChip(!useUrl, onClick={useUrl=false}, label={ Text("WebView") })
    }
    if(useUrl){
      OutlinedTextField(streamUrl, {streamUrl=it}, Modifier.fillMaxWidth(), label={ Text("URL (HLS/MP3/AAC)") })
      Row{ Text("Głośność"); Slider(vol, {vol=it}, 0f..1f, Modifier.weight(1f)) }
      Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button({urlPlayer.play()}){Text("Play")} ; Button({urlPlayer.pause()}){Text("Pause")} }
      Text("Auto‑play włączony przy zmianie URL")
    } else {
      OutlinedTextField(url, {url=it}, Modifier.fillMaxWidth(), label={ Text("Adres WWW") })
      AndroidView(factory={ c:Context -> WebView(c).apply{
        settings.javaScriptEnabled=true; settings.mediaPlaybackRequiresUserGesture=false; settings.cacheMode=WebSettings.LOAD_DEFAULT
        webChromeClient=WebChromeClient(); webViewClient=object: WebViewClient() {}; loadUrl(url)
      }}, update={ it.loadUrl(url) }, modifier=Modifier.weight(1f))
    }
  }
}