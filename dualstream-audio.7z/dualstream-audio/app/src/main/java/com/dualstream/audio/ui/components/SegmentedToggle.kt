package com.dualstream.audio.ui.components
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
@Composable
fun SegmentedToggle(options: List<String>, selected: Int, onChange: (Int)->Unit){
  Row { options.forEachIndexed { i,l -> FilterChip(selected==i,onClick={onChange(i)},label={ Text(l) }) } }
}