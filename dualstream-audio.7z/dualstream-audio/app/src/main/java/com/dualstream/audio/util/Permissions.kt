package com.dualstream.audio.util
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
fun createProjectionIntent(ctx: Context): Intent =
  (ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent()