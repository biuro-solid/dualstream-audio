package com.dualstream.audio.ui.screens
import androidx.compose.foundation.layout.*; import androidx.compose.material3.*; import androidx.compose.runtime.Composable; import androidx.compose.ui.Modifier; import androidx.compose.ui.unit.dp
@Composable fun OnboardingScreen(onRequestProjection:()->Unit, onDone:()->Unit){
  Column(Modifier.padding(16.dp)){
    Text("Krok 1: Nadaj uprawnienia mikrofonu i rozpocznij udostępnianie audio.")
    Spacer(Modifier.height(8.dp))
    Button(onClick=onRequestProjection){ Text("Udostępnij audio (MediaProjection)") }
    Spacer(Modifier.height(16.dp)); Text("Krok 2: Radio w innej aplikacji lub WebView/URL.")
    Spacer(Modifier.height(16.dp)); Text("Krok 3: Rozmowa = Mikrofon. (GSM/VoLTE rozmówca nie jest przechwytywany)")
    Spacer(Modifier.height(16.dp)); Button(onClick=onDone){ Text("Przejdź do miksera") }
  }
}