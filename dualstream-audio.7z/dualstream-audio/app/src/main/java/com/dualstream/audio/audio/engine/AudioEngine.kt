package com.dualstream.audio.audio.engine
import android.content.Context; import android.media.*; import android.media.projection.MediaProjection
import com.dualstream.audio.audio.capture.PlaybackCaptureSource
import com.dualstream.audio.audio.mic.MicSource
import com.dualstream.audio.audio.mixer.AudioMixer
import kotlinx.coroutines.*
class AudioEngine(private val ctx:Context){
  private val scope=CoroutineScope(Dispatchers.Default)
  private val mic=MicSource(); private val cap=PlaybackCaptureSource(); private val mix=AudioMixer()
  private var track:AudioTrack?=null; private var job:Job?=null
  fun setStereo(b:Boolean){ mix.mode=if(b) AudioMixer.Mode.STEREO else AudioMixer.Mode.MONO }
  fun setTalkGain(v:Float){ mix.talkGain=v }; fun setMusicGain(v:Float){ mix.musicGain=v }
  fun setTalkPan(p:Float){ mix.talkPan=p }; fun setMusicPan(p:Float){ mix.musicPan=p }
  suspend fun start(mp:MediaProjection){
    stop(); mic.start(); cap.start(mp)
    val attrs=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    val fmt=AudioFormat.Builder().setSampleRate(48000).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
    val min=AudioTrack.getMinBufferSize(48000,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_FLOAT)
    track=AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(fmt).setBufferSizeInBytes(min*2).setTransferMode(AudioTrack.MODE_STREAM).build()
    track?.play()
    job=scope.launch{
      val N=1024; val outL=FloatArray(N); val outR=FloatArray(N); val t=FloatArray(N); val mL=FloatArray(N); val mR=FloatArray(N); val inter=FloatArray(N*2)
      while(isActive){
        mic.readMono(t,N); cap.readStereo(mL,mR,N); mix.render(outL,outR,t,mL,mR,N)
        var i=0; var j=0; while(i<N){ inter[j++]=outL[i]; inter[j++]=outR[i]; i++ }
        track?.write(inter,0,inter.size,AudioTrack.WRITE_BLOCKING)
      }
    }
  }
  suspend fun stop(){ job?.cancel(); try{ job?.cancelAndJoin() }catch{}; track?.stop(); track?.release(); track=null; mic.stop(); cap.stop(); job=null }
  fun playTestLR(){ val frames=48000/2; val buf=FloatArray(frames*2); val f=440.0
    for(i in 0 until frames){ val s=Math.sin(2.0*Math.PI*f*i/48000).toFloat(); buf[i*2]=s; buf[i*2+1]=0f }; track?.write(buf,0,buf.size,AudioTrack.WRITE_BLOCKING)
    for(i in 0 until frames){ val s=Math.sin(2.0*Math.PI*f*i/48000).toFloat(); buf[i*2]=0f; buf[i*2+1]=s }; track?.write(buf,0,buf.size,AudioTrack.WRITE_BLOCKING)
  }
}