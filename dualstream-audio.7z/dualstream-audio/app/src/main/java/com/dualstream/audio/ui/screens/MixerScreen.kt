package com.dualstream.audio.ui.screens
import androidx.compose.foundation.layout.*; import androidx.compose.material3.*; import androidx.compose.runtime.*; import androidx.compose.ui.Modifier; import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dualstream.audio.ui.components.Fader; import com.dualstream.audio.ui.components.SegmentedToggle
import com.dualstream.audio.viewmodel.MixerViewModel
@Composable fun MixerScreen(onOpenWeb:()->Unit,onOpenDiagnostics:()->Unit,onOpenAbout:()->Unit){
  val vm: MixerViewModel = viewModel(); val isStereo by vm.isStereo.collectAsState(true)
  Column(Modifier.padding(16.dp)){
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){
      Text("Tryb"); SegmentedToggle(listOf("STEREO","MONO"), if(isStereo)0 else 1){ vm.toggleStereo() }
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly){
      Fader("Rozmowa",1f){}; Fader("Muzyka",1f){}
    }
    Spacer(Modifier.height(12.dp)); Text("Preset balansu")
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
      listOf("50/50","70/30","30/70").forEach{ p -> FilterChip(selected=(p==vm.balancePreset), onClick={ vm.setBalancePreset(p) }, label={ Text(p) }) }
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly){
      Button(onClick=vm::startService){ Text("Start miksu") }
      Button(onClick=vm::stopService){ Text("Stop") }
      Button(onClick=vm::testLR){ Text("Test L/R") }
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly){
      Button(onClick=onOpenWeb){ Text("WebView / URL") }
      Button(onClick=onOpenDiagnostics){ Text("Diagnostyka") }
      Button(onClick=onOpenAbout){ Text("O aplikacji") }
    }
  }
}