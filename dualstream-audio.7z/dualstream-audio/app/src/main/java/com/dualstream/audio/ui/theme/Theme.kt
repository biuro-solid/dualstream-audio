package com.dualstream.audio.ui.theme
import androidx.compose.material3.*; import androidx.compose.runtime.Composable
@Composable fun DualStreamTheme(content:@Composable ()->Unit){ MaterialTheme(colorScheme=lightColorScheme(), content=content) }