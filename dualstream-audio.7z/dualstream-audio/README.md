# DualStream Audio
Kotlin + Compose, minSdk 29. Mix mikrofonu z muzyką (AudioPlaybackCapture/WebView/URL). STEREO/MONO, presety 50/50,70/30,30/70, Test L/R. Pomysłodawca: Tomasz Kolasa.
## Build APK (GitHub)
Skopiuj ten projekt do repo i uruchom Actions → app-release.apk.